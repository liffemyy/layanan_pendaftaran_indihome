<nav class="navbar">
    <div class="logo">
        <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo IndiHome">
    </div>
    <ul class="nav-links">
        <li><a href="<?= base_url('/') ?>">Home</a></li>
        <li><a href="<?= base_url('paket') ?>">Paket</a></li>
        <li><a href="<?= base_url('cek-status') ?>">Cek Status</a></li>
        <li><a href="<?= base_url('kontak') ?>">Kontak</a></li>
        <li><a href="<?= base_url('keluhan') ?>">Layanan Gangguan</a></li>
    </ul>
</nav>
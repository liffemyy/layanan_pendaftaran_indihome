<?php
namespace App\Controllers;
use App\Models\PendaftaranModel;

class AdminPendaftaran extends BaseController
{
   public function index()
{
    if (!session()->get('isAdminLoggedIn')) return redirect()->to('/admin/login');

    $pendaftaranModel = new PendaftaranModel();
    $semua = $pendaftaranModel
        ->select('pendaftaran.*, paket.tipe_bayar, paket.kecepatan_judul, paket.harga as harga_paket')
        ->join('paket', 'paket.id = pendaftaran.paket_id', 'left')
        ->orderBy('pendaftaran.created_at', 'DESC')
        ->findAll();

    return view('admin/pendaftaran', ['semua' => $semua]);
}

    public function updateStatus()
    {
        if (!session()->get('isAdminLoggedIn')) return redirect()->to('/admin/login');

        $pendaftaranModel = new PendaftaranModel();

        $id = $this->request->getPost('id');
        $statusBaru = $this->request->getPost('status');

        $pendaftaranModel->update($id, ['status' => $statusBaru]);

        return redirect()->to('/admin/pendaftaran')->with('success', 'Status berhasil diubah.');
    }
}